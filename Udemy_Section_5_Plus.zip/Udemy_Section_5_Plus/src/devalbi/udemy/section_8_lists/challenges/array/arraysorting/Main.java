package devalbi.udemy.section_8_lists.challenges.array.arraysorting;

public class Main {
    public static void main(String[] args) {
        ArraySortChallenge arraySortChallenge = new ArraySortChallenge();
    }
}
