package devalbi.udemy.section_8_lists.challenges.array.minelement;

public class Main {
    public static void main(String[] args) {
        MinimumElement minimumElement = new MinimumElement();
    }
}
