package devalbi.udemy.section_7_oop_2.work.compositionExample.cars;

/**
 * Created by dev on 16/07/15.
 */
public class Vehicle {

    private String name;

    public Vehicle(String name) {
        this.name = name;
    }
}
