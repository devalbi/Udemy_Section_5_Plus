package devalbi.udemy.section_7_oop_2.challenges.oopFinal.dulexe;

public class Fries {
    //Created class to use Compounding
    private String name;

    public Fries(String name){
        this.name = name;
    }

    public Fries(){
        this.name = "Regular";
    }

    public String getName() {
        return name;
    }
}
